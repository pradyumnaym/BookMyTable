package com.example.restaurantcards;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.widget.TextView;

public class RestaurantDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_details);
        Intent i = getIntent();
        String id = i.getStringExtra("id");
        TextView v= (TextView)findViewById(R.id.IDTEXT);
        v.setText(id);
    }
}
